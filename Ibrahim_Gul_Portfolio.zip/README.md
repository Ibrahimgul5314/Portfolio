# Ibrahim Gul — Portfolio

This is a static, single-page portfolio site. It has no build step — just `index.html` plus an `assets/img/` folder of images.

## How to publish it on GitHub Pages (free link)

1. Go to your existing repo: `https://github.com/ibrahimgul5314/Portfolio`
   (If you don't have it yet, create a new repo named **Portfolio**.)
2. On the repo page, click **Add file → Upload files**.
3. Drag in `index.html` and the whole `assets` folder (keep the folder structure — don't flatten it).
4. Commit the changes (this replaces the old files).
5. Go to **Settings → Pages** (left sidebar).
6. Under **Source**, choose **Deploy from a branch**, branch = `main`, folder = `/root`, then **Save**.
7. Wait 1–2 minutes. Your site will be live at:
   `https://ibrahimgul5314.github.io/Portfolio`

That's it — the same link you already have on your CV. Every time you want to update the site, just re-upload the changed files and commit.

## Folder structure

```
index.html          ← the whole site (HTML/CSS/JS in one file)
assets/img/          ← every photo, certificate, and project render used on the site
```

## Notes

- All images are now separate files instead of being embedded in the HTML, so the page loads much faster and the code is easy to read/edit.
- If you ever add a new project or certificate photo, just drop the image into `assets/img/` and reference it in `index.html` as `assets/img/your-file-name.jpg`.
